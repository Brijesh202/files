#include "project.h"
#include "RC522.h"
#include <stdio.h>

uint8_t version;

int main(void)
{
    CyGlobalIntEnable;
    SPI_Start();
    PCD_Init();

    // Read Version before RESET
    version = PCD_ReadRegister(VersionReg);
    printf("Version before RESET: 0x%X\n", version);

    // Apply RESET
    RC522_RST_Write(0);    // Pull low
    CyDelay(10);           // wait 10ms
    RC522_RST_Write(1);    // Release high
    CyDelay(10);

    // Read Version after RESET
    version = PCD_ReadRegister(VersionReg);
    printf("Version after RESET: 0x%X\n", version);

    for(;;);
}
