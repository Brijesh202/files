/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "RC522.h"

unsigned char status;

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    LCD_Start();
    SPI_Start();
    // PCD_Init();
 
      LCD_Position(0,0);  LCD_PrintString("Version: "); 
       LCD_PrintHexUint8(PCD_ReadRegister(VersionReg));   // test PCD_ReadRegister()
    
        
    PCD_AntennaOn() ; PCD_ReadRegister(TxControlReg);   // for test PCD_WriteRegister()
    PCD_AntennaOff(); PCD_ReadRegister(TxControlReg);
    
    for(;;)
    {
    PCD_Reset();
    PCD_Init();  
    PCD_WriteRegister(BitFramingReg,     0x07); //BitFraming

    PCD_WriteRegister(CommIEnReg,        0xF7);      //CommIEn
    PCD_ClearRegisterBitMask( ComIrqReg, 0x80);     // ComIrq
    PCD_SetRegisterBitMask( FIFOLevelReg,0x80);     //immediately clears the internal FIFO   buffer’s   and   pointers
    PCD_WriteRegister(CommandReg,        0x00);     // idle
    //fill Tx  buffer 
    PCD_WriteRegister( FIFODataReg,        0x26); 
    // end fill Tx  buffer 
    PCD_WriteRegister( CommandReg,        0x0C);    //send data, activate read
    PCD_SetRegisterBitMask( BitFramingReg,0x80);    //  buffer
    
    // while
    status=PCD_ReadRegister(ComIrqReg) & 0b0100000;    //  test bit 6
    // end   while
   
    if(status) { LCD_Position(1,0);  LCD_PrintString("Card Present");  } 
    else{ LCD_Position(1,0);  LCD_PrintString("  NO Card        ");  }
    CyDelay(500);
    }
}

/* [] END OF FILE */
