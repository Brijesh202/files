/* ========================================
*
The following firmware was developed by Cypress Semiconductor
This work is licensed under a Creative Commons Attribution 3.0 Unported License.
http://creativecommons.org/licenses/by/3.0/deed.en_US
You are free to:
-To Share — to copy, distribute and transmit the work 
-To Remix — to adapt the work 
-To make commercial use of the work
*
*  Project name	: RFID URL Writer
*  Developer 	: CJ Cullen
*
* ========================================
*/
#include <device.h>
#include "Adafruit_NFCShield_I2C.h"

// URL for Cypress PSoC 4 website
#define MY_URL "cypress.com/?id=4749"

// Helper functions to make LEDs blink w/ the attached clock
void setLED_RedHSIOM(uint8 hsiomVal);
void setLED_GreenHSIOM(uint8 hsiomVal);

void main()
{
    uint8 success = 1;
    uint8 uid[] = {0, 0, 0, 0, 0, 0, 0 };
    uint8 uidLength;
    
    I2C_Start();
    CyGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */
    
    // configure board to read RFID tags
    SAMConfig();
    
    for(;;)
    {
        // Solid green for success (and startup), solid red for failure
        if (success)
            LED_Green_Write(0);
        else
            LED_Red_Write(0);
            
        setLED_RedHSIOM(0x00);
        setLED_GreenHSIOM(0x00);
        CyDelay(2000);

        // Show solid yellow until we find a card
        LED_Red_Write(0);
        LED_Green_Write(0);
        
        // Wait until a MIFARE card comes into range.
        success = 0;
        while (success == 0)
        {
            success = readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, &uidLength);
            CyDelay(10);
        }
        
        // Blink yellow to show that we are programming the card:
        // Set the pins to be driven by the clock, write '1' to the DR to enable drive from the UDB
        LED_Red_Write(1);
        LED_Green_Write(1);
        setLED_RedHSIOM(0x03);
        setLED_GreenHSIOM(0x03);
        
        // Make sure this is a Mifare Classic card w/ UID length 4
        success = (uidLength == 4);
        if (!success)
            continue;

        // We found a Mifare Classic card
        uint8 keya[6] =         { 0xD3, 0xF7, 0xD3, 0xF7, 0xD3, 0xF7 };
        uint8 keya_mad[6] =     { 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5 };
        uint8 keya_fact[6] =    { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
        
        // Try to authenticate the MAD sector with the standard MAD KEYA.
        success = mifareclassic_AuthenticateBlock(uid, uidLength, 0, 0, keya_mad);
        if (!success)
        {
            // That didn't work, try the factory default key.
            readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, &uidLength);
            success = mifareclassic_AuthenticateBlock(uid, uidLength, 0, 0, keya_fact);
        }
        
        // Format the MAD sector for NDEF
        success = mifareclassic_FormatNDEF ();
        if (!success)
            continue;
        
        readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, &uidLength);
        
        // Try to authenticate sector 1 with the standard KEYA.
        success = mifareclassic_AuthenticateBlock(uid, uidLength, 4, 0, keya);
        if (!success)
        {
            // That didn't work, try the factory default key.
            readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, &uidLength);
            success = mifareclassic_AuthenticateBlock(uid, uidLength, 4, 0, keya_fact);
        }
        // Bail if we are unable to authenticate.
        if (!success)
            continue;
        
        // Write Sector 1 with our URL (0x03 is the "http://" record type as defined in RFC 3987)
        success = mifareclassic_WriteNDEFURI (1, 0x03, MY_URL);
        if (!success)
            continue;

        // Write the rest of the sector trailers with the default key (if they don't already have it)
        uint8 sec_trailer[16] = { 0xD3, 0xF7, 0xD3, 0xF7, 0xD3, 0xF7, 0x7F, 0x07, 0x88, 0x40, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
        int sectorNum;
        for (sectorNum = 2; sectorNum < 16; ++sectorNum)
        {
            uint8 usesFactoryKey = 0;

            // Try to authenticate with the standard KEYA.
            readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, &uidLength);
            success = mifareclassic_AuthenticateBlock(uid, uidLength, sectorNum*4, 0, keya);
            if (!success)
            {
                // That didn't work, try the factory default key.
                success = readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, &uidLength);
                if (success)
                {
                    success = mifareclassic_AuthenticateBlock(uid, uidLength, sectorNum*4, 0, keya_fact);
                    usesFactoryKey = 1;
                }
            }
            // Bail if we are unable to authenticate.
            if (!success)
                break;

            if (usesFactoryKey)
                mifareclassic_WriteDataBlock (sectorNum*4+3, sec_trailer);
        }
    }
}

void setLED_RedHSIOM(uint8 hsiomVal)
{
    uint32 red_HSIOM = (CY_GET_REG32(LED_Red__0__HSIOM) & ~LED_Red__0__HSIOM_MASK) | (hsiomVal << LED_Red__0__HSIOM_SHIFT);
    CY_SET_REG32(LED_Red__0__HSIOM, red_HSIOM);
}

void setLED_GreenHSIOM(uint8 hsiomVal)
{
    uint32 green_HSIOM = (CY_GET_REG32(LED_Green__0__HSIOM) & ~LED_Green__0__HSIOM_MASK) | (hsiomVal << LED_Green__0__HSIOM_SHIFT);
    CY_SET_REG32(LED_Green__0__HSIOM, green_HSIOM);
}

/* [] END OF FILE */
