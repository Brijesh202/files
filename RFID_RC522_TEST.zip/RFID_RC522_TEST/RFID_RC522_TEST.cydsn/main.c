#include "project.h"
#include "RC522.h"  // Your RC522 driver header

int main(void)
{
    CyGlobalIntEnable;
    
    // Initialize
    SPI_Start();
    
    // Initialize RC522
    PCD_Init();
    
    // 3 blinks = ready
    for(int i=0; i<3; i++) {
        Red_Write(0); CyDelay(200);
        Red_Write(1); CyDelay(200);
    }
    
    CyDelay(1000);
    
    for(;;)
    {
        // Check for card
        if(PICC_IsNewCardPresent())
        {
            
            // Read card UID
            if(PICC_ReadCardSerial())
            {
                // Card detected - SOLID ON for 500ms
                Red_Write(0);
                CyDelay(500);
                
                // Blink while card present
                while(PICC_IsNewCardPresent()) {
                    Red_Write(1); CyDelay(200);
                    Red_Write(0); CyDelay(200);
                }
                
                // Card removed - OFF
                Red_Write(1);
                CyDelay(500);
            }
        }
        
        CyDelay(100);  // Check every 100ms
    }
}